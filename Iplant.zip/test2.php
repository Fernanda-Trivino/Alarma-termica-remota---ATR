<?php
header('Content-type: Application/JSON');
/* Creamos la conexion  y cada una de las variables para la conexion*/
$servidor =  "localhost" ; 
$usuario  = "admin" ; 
$contrasena = "raspberry" ; 
$basededatos = "Iplant" ; 

$conexion = mysqli_connect($servidor, $usuario,  $contrasena,  $basededatos);

if($conexion){
/* la conexion es exitosa*/ 
/* la tarea sql ,  en este caso vamos a leer todos los datos*/
$sql = "SELECT  * FROM  Sensores2 ORDER BY Temperatura DESC LIMIT 1"; 
/*Establecemos conexion entre la  conexion inicial  y la tarea*/
$resultado = mysqli_query($conexion, $sql);
/*Creamos una variable donde almacenar los datos,  creamos   un arreglo  */

$json_array= array(); 

if($resultado){

while($row=mysqli_fetch_assoc($resultado)){
$json_array['datos'][] = $row  ;

}

echo json_encode($json_array);
/*Imprime el arreglo */
//echo  '<pre>'; 
//print_r($datos);
//echo  '</pre>';

}
else
{
echo "Existe un error , verifique";

}


} 
else{
/* La conexion posee errores ,  por lo tanto  necesita verificacion */ 
echo "Imposible   realizar la conexion ,  verifique " ; 
}


?>

