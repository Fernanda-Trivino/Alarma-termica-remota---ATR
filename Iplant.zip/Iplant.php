<?php  
$con = mysqli_connect("localhost","admin","raspberry","Iplant"); 
?>

<!DOCTYPE html>
 
<html lang="es">
 
<head>
<title>Proyecti I-PLant</title>
<link rel="stylesheet" type="text/css" href="estilo.css"> 
<meta charset="utf-8" />
   <link rel="stylesheet" href="estilo.css" />
</head>
        <body>
                  <div  id="main">
                    <header>
                       <h1>I-plant- Al cuidado de tus PLantas</h1>
                   </header>

                   <section>
                      <article>
                       <h2>Ornamentales </h2>
                       <p>
                       Tipos de Plantas para tu hogar:<br />
                       <img src="html/imagenes/prueba.jpg" alt="Foto de la monta  a" />
                       </p>

                       </article>
                    </section>

                    <aside>

                    <h3>Titulo de contenido</h3>
                     <p>contenido</p>

                     <center>
                     <table border="3">
                     <tr>
                        <td>Temperatura</td>
                        <td>Humedad</td>
                        <td>Calidad_aire</td>
                     </tr>

                      <?php  
                       $sql=  "SELECT * FROM  Sensores2"; 
                      $result = mysqli_query($con,$sql);
                    while($mostrar=mysqli_fetch_array($result)){
                        ?>
                     <tr>
                    <td><?php echo $mostrar['Temperatura']?> </td>
                        <td><?php echo$mostrar['Humedad']?></td>
                        <td><?php echo$mostrar['Calidad_aire']?></td>
                    </tr>
                    <?php 
                    }
                    ?>
                    </table>
                    </center>

                    </aside>

                    <footer>
                         I-Plant 2019 All Rights Reseverved
                    </footer>

           </div>
      </body>
<script type="text/javacript">
 function actualizar() {location.reload(true);}
 setInterval("actualizar()",5000);
</script>
</html>




